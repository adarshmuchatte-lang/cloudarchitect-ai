const crypto = require('crypto');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { BedrockRuntimeClient, ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');
const { recommend } = require('./recommendationEngine');

const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}), { marshallOptions: { removeUndefinedValues: true } });
const bedrock = new BedrockRuntimeClient({ region: process.env.BEDROCK_REGION || process.env.AWS_REGION });
const TABLE_NAME = process.env.TABLE_NAME;
const MODEL_ID = process.env.BEDROCK_MODEL_ID || 'amazon.nova-lite-v1:0';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN || '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
};
const response = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });

function getUser(event) {
  const claims = event.requestContext?.authorizer?.claims || {};
  const sub = claims.sub;
  if (!sub) throw Object.assign(new Error('Authenticated user identity was not found.'), { statusCode: 401 });
  return { sub, email: claims.email || '' };
}

function parseBody(event) {
  try { return event.body ? JSON.parse(event.body) : {}; }
  catch { throw Object.assign(new Error('Request body must be valid JSON.'), { statusCode: 400 }); }
}

async function explainWithBedrock(result) {
  const compact = {
    requirements: result.requirements,
    trafficClass: result.trafficClass,
    costCategory: result.costCategory,
    services: result.services.map(s => s.name),
    notes: result.notes
  };
  const prompt = `Explain this AWS architecture recommendation to a beginner in 3-5 concise paragraphs. The service selection is deterministic and final: do not add, remove, or replace services. Explain why the selected services fit the requirements, mention the ${result.costCategory} cost category is qualitative rather than a price quote, and finish with one short production-readiness caution. Architecture: ${JSON.stringify(compact)}`;
  try {
    const out = await bedrock.send(new ConverseCommand({
      modelId: MODEL_ID,
      system: [{ text: 'You are CloudArchitect AI. Explain AWS architectures accurately, clearly, and conservatively. Never change the deterministic service list.' }],
      messages: [{ role: 'user', content: [{ text: prompt }] }],
      inferenceConfig: { maxTokens: 700, temperature: 0.2 }
    }));
    const text = out.output?.message?.content?.map(x => x.text || '').join('\n').trim();
    if (text) return { text, source: 'Amazon Bedrock' };
    throw new Error('Bedrock returned no text');
  } catch (err) {
    console.warn('Bedrock explanation unavailable:', err.name, err.message);
    const names = result.services.map(s => s.name).join(', ');
    return {
      text: `This design uses ${names}. The deterministic engine selected these services from the submitted workload, database, availability, budget, and authentication requirements. The ${result.costCategory} cost category is a relative planning indicator, not a monetary estimate. Review quotas, security, resilience, and actual AWS Pricing Calculator estimates before production use.`,
      source: 'Deterministic fallback',
      warning: 'Bedrock was unavailable; a built-in explanation was used.'
    };
  }
}

async function generate(event) {
  const user = getUser(event);
  const result = recommend(parseBody(event));
  const explanation = await explainWithBedrock(result);
  return response(200, {
    recommendationId: crypto.randomUUID(),
    generatedAt: new Date().toISOString(),
    user: { email: user.email },
    ...result,
    explanation
  });
}

function sanitizeRecommendation(body) {
  if (!body || typeof body !== 'object' || !body.recommendationId || !Array.isArray(body.services) || !body.requirements) {
    throw Object.assign(new Error('A valid generated recommendation is required.'), { statusCode: 400 });
  }
  return {
    recommendationId: String(body.recommendationId).slice(0, 80),
    generatedAt: String(body.generatedAt || new Date().toISOString()),
    requirements: body.requirements,
    trafficClass: body.trafficClass,
    costCategory: body.costCategory,
    services: body.services.slice(0, 20),
    notes: Array.isArray(body.notes) ? body.notes.slice(0, 10) : [],
    disclaimer: body.disclaimer,
    explanation: body.explanation
  };
}

async function save(event) {
  const user = getUser(event);
  const item = sanitizeRecommendation(parseBody(event));
  const createdAt = new Date().toISOString();
  await ddb.send(new PutCommand({
    TableName: TABLE_NAME,
    Item: { userId: user.sub, recommendationKey: `${createdAt}#${item.recommendationId}`, createdAt, ...item }
  }));
  return response(201, { saved: true, recommendationId: item.recommendationId, createdAt });
}

async function history(event) {
  const user = getUser(event);
  const limit = Math.min(50, Math.max(1, Number(event.queryStringParameters?.limit) || 20));
  const data = await ddb.send(new QueryCommand({
    TableName: TABLE_NAME,
    KeyConditionExpression: 'userId = :uid',
    ExpressionAttributeValues: { ':uid': user.sub },
    ScanIndexForward: false,
    Limit: limit
  }));
  const items = (data.Items || []).map(({ userId, recommendationKey, ...rest }) => rest);
  return response(200, { items });
}

exports.handler = async (event) => {
  try {
    const method = event.httpMethod;
    const path = event.resource || event.path;
    if (method === 'OPTIONS') return response(204, {});
    if (method === 'POST' && path.endsWith('/recommend')) return await generate(event);
    if (method === 'POST' && path.endsWith('/recommendations')) return await save(event);
    if (method === 'GET' && path.endsWith('/recommendations')) return await history(event);
    return response(404, { error: 'Route not found' });
  } catch (err) {
    console.error(err);
    return response(err.statusCode || 500, { error: err.statusCode ? err.message : 'Internal server error' });
  }
};
