const SERVICE = {
  s3: { id: 's3', name: 'Amazon S3', category: 'Storage', reason: 'Durable object storage for static assets, uploads, backups, and application files.' },
  api: { id: 'api-gateway', name: 'Amazon API Gateway', category: 'API', reason: 'Managed HTTPS entry point with throttling, authorization integration, and scalable request routing.' },
  cloudwatch: { id: 'cloudwatch', name: 'Amazon CloudWatch', category: 'Observability', reason: 'Centralized logs, metrics, alarms, and operational visibility.' },
  lambda: { id: 'lambda', name: 'AWS Lambda', category: 'Compute', reason: 'Serverless compute scales per request and minimizes infrastructure management for small and medium workloads.' },
  fargate: { id: 'fargate', name: 'AWS Fargate', category: 'Compute', reason: 'Managed container compute suits sustained, larger workloads without managing EC2 servers.' },
  alb: { id: 'alb', name: 'Application Load Balancer', category: 'Networking', reason: 'Distributes sustained application traffic across container tasks and supports health checks.' },
  rds: { id: 'rds', name: 'Amazon RDS / Aurora', category: 'Database', reason: 'Managed relational database with SQL, backups, and optional Multi-AZ resilience.' },
  dynamodb: { id: 'dynamodb', name: 'Amazon DynamoDB', category: 'Database', reason: 'Managed NoSQL database with low-latency access and automatic scaling.' },
  cognito: { id: 'cognito', name: 'Amazon Cognito', category: 'Security', reason: 'Managed sign-up, sign-in, email verification, and token-based authentication.' },
  cloudfront: { id: 'cloudfront', name: 'Amazon CloudFront', category: 'Delivery', reason: 'Edge caching reduces latency and offloads origin traffic for larger or highly available applications.' },
  route53: { id: 'route53', name: 'Amazon Route 53', category: 'Networking', reason: 'Managed DNS and health-aware routing improve availability and domain management.' },
  bedrock: { id: 'bedrock', name: 'Amazon Bedrock', category: 'AI', reason: 'Generates a beginner-friendly explanation after the deterministic engine selects the architecture.' }
};

function normalize(input = {}) {
  const expectedUsers = Math.max(1, Math.min(100000000, Number(input.expectedUsers) || 100));
  const budget = ['low','medium','high'].includes(input.budget) ? input.budget : 'medium';
  const database = ['none','relational','nosql'].includes(input.database) ? input.database : 'none';
  const availability = ['standard','high'].includes(input.availability) ? input.availability : 'standard';
  return {
    applicationType: String(input.applicationType || 'web').slice(0, 60),
    expectedUsers,
    budget,
    database,
    availability,
    authentication: Boolean(input.authentication)
  };
}

function classifyTraffic(users) {
  if (users <= 10000) return 'small';
  if (users <= 100000) return 'medium';
  return 'large';
}

function estimateCost(req, traffic) {
  let score = 0;
  if (traffic === 'medium') score += 1;
  if (traffic === 'large') score += 3;
  if (req.database === 'relational') score += 2;
  if (req.database === 'nosql') score += 1;
  if (req.availability === 'high') score += 2;
  if (req.authentication) score += 1;
  if (req.budget === 'high') score += 1;
  return score <= 2 ? 'Low' : score <= 5 ? 'Medium' : 'High';
}

function recommend(raw) {
  const requirements = normalize(raw);
  const traffic = classifyTraffic(requirements.expectedUsers);
  const services = [SERVICE.s3, SERVICE.api, SERVICE.cloudwatch];
  const notes = [];

  if (traffic === 'large') {
    services.push(SERVICE.fargate, SERVICE.alb);
    notes.push('Large sustained workload: container-based compute is preferred over request-driven Lambda.');
  } else {
    services.push(SERVICE.lambda);
    notes.push('Small/medium workload: serverless compute reduces operational overhead and scales with requests.');
  }

  if (requirements.database === 'relational') {
    services.push({ ...SERVICE.rds, reason: requirements.availability === 'high' ? SERVICE.rds.reason + ' Multi-AZ is recommended for this high-availability requirement.' : SERVICE.rds.reason });
  } else if (requirements.database === 'nosql') {
    services.push(SERVICE.dynamodb);
  }

  if (requirements.authentication) services.push(SERVICE.cognito);
  if (traffic !== 'small' || requirements.availability === 'high') services.push(SERVICE.cloudfront);
  if (requirements.availability === 'high') services.push(SERVICE.route53);
  services.push(SERVICE.bedrock);

  if (requirements.budget === 'low' && traffic === 'large') {
    notes.push('Budget/traffic tension detected: validate expected sustained traffic and apply AWS Budgets before production deployment.');
  }
  if (requirements.database === 'none') notes.push('No managed application database is included because the user selected “No database”.');

  return {
    requirements,
    trafficClass: traffic,
    costCategory: estimateCost(requirements, traffic),
    services,
    notes,
    disclaimer: 'Educational architecture recommendation. Validate security, quotas, compliance, resilience, and cost before production use.'
  };
}

module.exports = { recommend, normalize };
