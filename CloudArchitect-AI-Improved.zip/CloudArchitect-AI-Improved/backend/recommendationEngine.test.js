const assert = require('assert');
const { recommend } = require('./recommendationEngine');
const names = r => r.services.map(s => s.name);

let r = recommend({ expectedUsers: 500, budget: 'low', database: 'nosql', availability: 'standard', authentication: true });
assert(names(r).includes('AWS Lambda'));
assert(names(r).includes('Amazon DynamoDB'));
assert(names(r).includes('Amazon Cognito'));
assert(!names(r).includes('AWS Fargate'));

r = recommend({ expectedUsers: 500000, budget: 'high', database: 'relational', availability: 'high', authentication: true });
assert(names(r).includes('AWS Fargate'));
assert(names(r).includes('Application Load Balancer'));
assert(names(r).includes('Amazon RDS / Aurora'));
assert(names(r).includes('Amazon CloudFront'));
assert(names(r).includes('Amazon Route 53'));
assert.equal(r.costCategory, 'High');
console.log('Recommendation engine tests passed.');
