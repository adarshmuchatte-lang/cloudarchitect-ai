import json, sys
outputs=json.loads(sys.argv[1]); target=sys.argv[2]
d={x['OutputKey']:x['OutputValue'] for x in outputs}
content=("window.CLOUDARCHITECT_CONFIG = {\n" + f"  region: {json.dumps(d['Region'])},\n" + f"  userPoolId: {json.dumps(d['UserPoolId'])},\n" + f"  userPoolClientId: {json.dumps(d['UserPoolClientId'])},\n" + f"  apiUrl: {json.dumps(d['ApiUrl'])}\n" + "};\n")
open(target,'w',encoding='utf-8').write(content)
print('Wrote',target)
