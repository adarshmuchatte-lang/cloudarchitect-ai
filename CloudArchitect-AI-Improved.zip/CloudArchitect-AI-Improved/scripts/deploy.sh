#!/usr/bin/env bash
set -euo pipefail
STACK_NAME="${1:-cloudarchitect-ai}"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v aws >/dev/null || { echo "AWS CLI is required."; exit 1; }
command -v sam >/dev/null || { echo "AWS SAM CLI is required."; exit 1; }
aws sts get-caller-identity >/dev/null
npm --prefix backend install --omit=dev
node backend/recommendationEngine.test.js
sam validate
sam build
sam deploy --stack-name "$STACK_NAME" --region "$REGION" --resolve-s3 --capabilities CAPABILITY_IAM --no-confirm-changeset --no-fail-on-empty-changeset
OUT=$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs' --output json)
python3 scripts/write_config.py "$OUT" frontend/config.js
BUCKET=$(python3 -c 'import json,sys; o=json.loads(sys.argv[1]); print(next(x["OutputValue"] for x in o if x["OutputKey"]=="FrontendBucketName"))' "$OUT")
aws s3 sync frontend/ "s3://$BUCKET" --delete --region "$REGION" --exclude README.md
URL=$(python3 -c 'import json,sys; o=json.loads(sys.argv[1]); print(next(x["OutputValue"] for x in o if x["OutputKey"]=="FrontendUrl"))' "$OUT")
echo ""
echo "CloudArchitect AI deployed successfully."
echo "Frontend: $URL"
echo "Stack:    $STACK_NAME ($REGION)"
echo "If Bedrock is not enabled in this region/account, the app automatically uses a deterministic fallback explanation."
