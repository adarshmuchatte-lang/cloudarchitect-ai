param([string]$StackName = "cloudarchitect-ai", [string]$Region = "")
$ErrorActionPreference = "Stop"
if (-not $Region) { $Region = if ($env:AWS_REGION) { $env:AWS_REGION } elseif ($env:AWS_DEFAULT_REGION) { $env:AWS_DEFAULT_REGION } else { "us-east-1" } }
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
aws sts get-caller-identity | Out-Null
if ($LASTEXITCODE -ne 0) { throw "AWS CLI is not configured." }
npm --prefix backend install --omit=dev
node backend/recommendationEngine.test.js
sam validate
sam build
sam deploy --stack-name $StackName --region $Region --resolve-s3 --capabilities CAPABILITY_IAM --no-confirm-changeset --no-fail-on-empty-changeset
$Out = aws cloudformation describe-stacks --stack-name $StackName --region $Region --query 'Stacks[0].Outputs' --output json
python scripts/write_config.py $Out frontend/config.js
$Obj = $Out | ConvertFrom-Json
$Bucket = ($Obj | Where-Object OutputKey -eq "FrontendBucketName").OutputValue
$Url = ($Obj | Where-Object OutputKey -eq "FrontendUrl").OutputValue
aws s3 sync frontend/ "s3://$Bucket" --delete --region $Region
Write-Host "`nCloudArchitect AI deployed successfully."
Write-Host "Frontend: $Url"
Write-Host "Stack:    $StackName ($Region)"
Write-Host "If Bedrock is unavailable, the app uses a deterministic fallback explanation."
