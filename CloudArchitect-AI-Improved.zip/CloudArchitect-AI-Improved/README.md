# CloudArchitect AI

A deployable implementation of the CloudCrafters project: an authenticated web app that converts application requirements into deterministic AWS architecture recommendations and uses Amazon Bedrock only to explain the selected design.

## What is included

- Professional responsive HTML/CSS/JavaScript frontend
- Amazon Cognito sign-up, email verification, sign-in, sign-out
- API Gateway protected by a Cognito authorizer
- Node.js 20 AWS Lambda backend
- Deterministic service-selection engine
- Amazon Bedrock / Amazon Nova Lite explanation layer with graceful fallback
- DynamoDB per-user saved recommendation history
- Architecture flow visualization and qualitative Low / Medium / High cost category
- AWS SAM / CloudFormation infrastructure
- Bash and PowerShell deployment scripts that deploy the stack, inject generated AWS IDs into the frontend, and upload the frontend to S3
- Unit tests for core recommendation rules

## Rule logic implemented

Fundamentals: S3 + API Gateway + CloudWatch. Small/medium workloads use Lambda. Large workloads use Fargate + ALB. Relational data uses RDS/Aurora; NoSQL uses DynamoDB. Cognito is added when app authentication is requested. CloudFront is added for medium/large traffic or high availability; Route 53 is added for high availability. Bedrock explains the deterministic result and does not choose the services.

## Fast deployment

Prerequisites on the deployer's computer:
1. AWS CLI configured with the project AWS account (`aws configure` or SSO).
2. AWS SAM CLI.
3. Node.js 20+ and npm.
4. Permission to create CloudFormation/SAM resources, Lambda, API Gateway, Cognito, DynamoDB, S3, IAM roles/policies, and invoke Bedrock.
5. Amazon Nova Lite access/availability in the chosen region. If Bedrock invocation is unavailable, the app still runs and shows a deterministic fallback explanation.

macOS/Linux:

    chmod +x scripts/deploy.sh
    ./scripts/deploy.sh cloudarchitect-ai

Windows PowerShell:

    .\scripts\deploy.ps1 -StackName cloudarchitect-ai -Region us-east-1

The script prints the frontend URL after deployment. Open it, create an account, verify the email, sign in, generate an architecture, save it, and open History.

## Manual deployment

    npm --prefix backend install --omit=dev
    node backend/recommendationEngine.test.js
    sam validate
    sam build
    sam deploy --guided

Then obtain CloudFormation outputs, replace the placeholders in `frontend/config.js`, and sync the `frontend/` directory to the generated `FrontendBucketName`.

## Demo path

1. Create account → email verification → sign in.
2. Enter application type, expected users, budget, database, availability, authentication.
3. Generate recommendation.
4. Show service cards + architecture flow + cost category + Bedrock explanation.
5. Save recommendation.
6. Open History and show user-specific persistence.

## Important note

This is an educational architecture recommendation prototype, not an automatic production infrastructure generator. It recommends an architecture; it does not provision the recommended RDS/Fargate/CloudFront/etc. workload for the user's hypothetical application.


## Local run (PowerShell, no AWS deployment)

From the extracted project folder:

```powershell
# Start a static server for the frontend (Python 3 required)
py -m http.server 8000 --directory frontend
# Open http://localhost:8000 in your browser
```

The checked-in `frontend/config.js` contains the project's existing `REPLACE_...` configuration markers. Keep your actual deployed values if you have them; do not overwrite them with sample values. With markers still present, the landing page can be previewed locally, but Cognito sign-in and authenticated recommendation/API features require valid existing Cognito and API Gateway configuration. This local command does not deploy or modify AWS resources.

## Architecture Studio enhancements

- Service cards and graph nodes open a detailed inspector with purpose, selection rationale, design-level connection hints, and configuration considerations.
- Graph nodes can be dragged individually; the graph can be panned and zoomed, and linked edges update while dragging.
- Export the current recommendation and node layout to JSON, or export the graph to PNG/SVG.
- A cost panel explains the existing Low/Medium/High rule-based category and its cost drivers. It intentionally does **not** invent dollar amounts or call the AWS Pricing API.
- Architecture comparison loads previously saved recommendations through the existing `GET /recommendations?limit=50` API route.
- No backend routes, API URL, Cognito settings, SAM template, IAM permissions, or live AWS resources were changed for these UI enhancements.

### Important boundaries

Connection hints in the inspector are explanatory diagram relationships, not proof that those recommended resources are provisioned or connected in a live AWS account. The project still recommends architectures; it does not provision each recommended workload. A real monetary estimate would require additional pricing inputs and integration (or a clearly defined Pricing Calculator workflow). The comparison panel requires at least one other saved recommendation and the existing authenticated history API.
