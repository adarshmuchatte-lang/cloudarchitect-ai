const cfg = window.CLOUDARCHITECT_CONFIG || {};
const $ = id => document.getElementById(id);
let currentRecommendation = null;
let currentEmail = '';
let comparisonItems = [];
let pool;
let graphState = { scale: 1, x: 0, y: 0, dragging: false, px: 0, py: 0, lastX: 0, lastY: 0 };

function configured() { return cfg.userPoolId && !String(cfg.userPoolId).startsWith('REPLACE_'); }
function initPool() {
  if (!configured()) return;
  pool = new AmazonCognitoIdentity.CognitoUserPool({ UserPoolId: cfg.userPoolId, ClientId: cfg.userPoolClientId });
}
function showMessage(text, bad=false) { const el=$('authMessage'); el.textContent=text; el.classList.remove('hidden'); el.style.borderColor=bad?'#7f1d1d':'#36506e'; }
function toast(text){ const el=$('toast'); el.textContent=text; el.classList.remove('hidden'); setTimeout(()=>el.classList.add('hidden'),2800); }
function switchTab(name){ document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name)); ['login','signup','confirm'].forEach(x=>$(x+'Form').classList.toggle('hidden',x!==name)); $('authMessage').classList.add('hidden'); }
document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>switchTab(t.dataset.tab)));
function sessionUser(){ return pool?.getCurrentUser(); }
function getSession(){ return new Promise((resolve,reject)=>{ const user=sessionUser(); if(!user) return reject(new Error('Please sign in again.')); user.getSession((err,session)=>err?reject(err):resolve({user,session})); }); }
async function api(path, options={}) { const {session}=await getSession(); const res=await fetch(cfg.apiUrl+path,{...options,headers:{'Content-Type':'application/json','Authorization':session.getIdToken().getJwtToken(),...(options.headers||{})}}); let body={}; try{body=await res.json()}catch{} if(!res.ok) throw new Error(body.error||`Request failed (${res.status})`); return body; }
function showApp(email=''){ currentEmail=email; $('authSection').classList.add('hidden'); $('appSection').classList.remove('hidden'); $('logoutBtn').classList.remove('hidden'); $('historyBtn').classList.remove('hidden'); $('userLabel').textContent=email||'Authenticated user'; }
function showAuth(){ $('authSection').classList.remove('hidden'); $('appSection').classList.add('hidden'); $('logoutBtn').classList.add('hidden'); $('historyBtn').classList.add('hidden'); }

$('loginForm').addEventListener('submit',e=>{e.preventDefault(); if(!configured()) return showMessage('Frontend is not configured yet. Run the deployment script first.',true); const email=$('loginEmail').value.trim(); const user=new AmazonCognitoIdentity.CognitoUser({Username:email,Pool:pool}); const details=new AmazonCognitoIdentity.AuthenticationDetails({Username:email,Password:$('loginPassword').value}); user.authenticateUser(details,{onSuccess:()=>{showApp(email);toast('Signed in');},onFailure:err=>showMessage(err.message,true),newPasswordRequired:()=>showMessage('A new password is required for this account.',true)});});
$('signupForm').addEventListener('submit',e=>{e.preventDefault(); if(!configured()) return showMessage('Frontend is not configured yet. Run the deployment script first.',true); const email=$('signupEmail').value.trim(); pool.signUp(email,$('signupPassword').value,[new AmazonCognitoIdentity.CognitoUserAttribute({Name:'email',Value:email})],null,(err)=>{if(err)return showMessage(err.message,true);$('confirmEmail').value=email;$('confirmTab').classList.remove('hidden');switchTab('confirm');showMessage('Account created. Enter the verification code sent to your email.');});});
$('confirmForm').addEventListener('submit',e=>{e.preventDefault(); const email=$('confirmEmail').value.trim(); const user=new AmazonCognitoIdentity.CognitoUser({Username:email,Pool:pool}); user.confirmRegistration($('confirmCode').value.trim(),true,(err)=>{if(err)return showMessage(err.message,true);switchTab('login');$('loginEmail').value=email;showMessage('Email verified. You can sign in now.');});});
$('logoutBtn').addEventListener('click',()=>{sessionUser()?.signOut();currentRecommendation=null;showAuth();toast('Signed out');});

$('requirementsForm').addEventListener('submit',async e=>{
  e.preventDefault(); const btn=$('generateBtn'); btn.disabled=true;btn.innerHTML='Designing architecture <span class="loading-dots">···</span>';
  try{
    const payload={applicationType:$('applicationType').value,expectedUsers:Number($('expectedUsers').value),budget:$('budget').value,database:$('database').value,availability:$('availability').value,authentication:$('authentication').checked};
    currentRecommendation=await api('/recommend',{method:'POST',body:JSON.stringify(payload)});
    renderResult(currentRecommendation);
  }catch(err){toast(err.message)}finally{btn.disabled=false;btn.innerHTML='Generate architecture <span>↗</span>';}
});

function serviceIcon(s){
  const id=(s.id||'').toLowerCase();
  const map={s3:'S3', 'api-gateway':'API',cloudwatch:'CW',lambda:'λ',fargate:'FG',alb:'LB',rds:'DB',dynamodb:'DDB',cognito:'ID',cloudfront:'CDN',route53:'DNS',bedrock:'AI'};
  return map[id]||((s.name||'AWS').replace(/amazon |aws /i,'').slice(0,3).toUpperCase());
}
function serviceKey(s){ return String(s.id||s.name).toLowerCase().replace(/[^a-z0-9-]/g,'-'); }
function escapeHtml(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

function renderResult(r){
  $('resultSection').classList.remove('hidden');
  $('costBadge').textContent=`${r.costCategory} relative cost`;
  renderServices(r.services);
  renderGraph(r);
  renderDecisionTree(r);
  renderHealth(r);
  renderCostEstimate(r);
  $('comparisonPanel').innerHTML='<p class="hint">Load saved designs, then choose one to compare with this architecture.</p>';
  $('explanation').textContent=r.explanation?.text||'';
  $('explanationSource').textContent=`Explanation source: ${r.explanation?.source||'Unknown'}${r.explanation?.warning?' · '+r.explanation.warning:''}`;
  $('notes').innerHTML=(r.notes?.length?r.notes:['No additional design notes.']).map(n=>`<li>${escapeHtml(n)}</li>`).join('');
  $('disclaimer').textContent=r.disclaimer||'';
  $('resultSection').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
}

function renderServices(services){
  $('serviceGrid').innerHTML=services.map((s,i)=>`<button class="service-card" data-service="${i}">
    <span class="service-icon">${escapeHtml(serviceIcon(s))}</span><span class="category">${escapeHtml(s.category)}</span>
    <h3>${escapeHtml(s.name)}</h3><p>${escapeHtml(s.reason)}</p><span class="inspect">Inspect ↗</span>
  </button>`).join('');
  document.querySelectorAll('.service-card').forEach(btn=>btn.addEventListener('click',()=>inspectService(services[Number(btn.dataset.service)])));
}
function inspectService(s){
  document.querySelectorAll('.service-card').forEach(x=>x.classList.remove('selected'));
  const cards=[...document.querySelectorAll('.service-card')];
  const idx=currentRecommendation.services.indexOf(s); if(idx>=0) cards[idx]?.classList.add('selected');
  $('serviceInspector').innerHTML=`<div class="inspector-kicker">${escapeHtml(s.category)} · SERVICE NODE</div>
    <div class="inspector-icon">${escapeHtml(serviceIcon(s))}</div><h3>${escapeHtml(s.name)}</h3>
    <p>${escapeHtml(s.reason)}</p>
    <div class="inspector-role"><span>WHY SELECTED</span><strong>${escapeHtml(selectionReason(s,currentRecommendation))}</strong></div>
    <div class="inspector-detail"><span>PURPOSE</span><p>${escapeHtml(s.reason)}</p></div>
    <div class="inspector-detail"><span>CONNECTIONS</span><p>${escapeHtml(serviceConnections(s,currentRecommendation).join(' · ')||'No direct connection inferred by the visualization rules.')}</p></div>
    <div class="inspector-detail"><span>CONFIGURATION NOTES</span><p>${escapeHtml(configurationNotes(s,currentRecommendation))}</p></div>
    <p class="inspector-footnote">These are design-level notes. Resource-level settings are not provisioned by this recommendation.</p>`;
}
function selectionReason(s,r){
  const q=r.requirements||{};
  if(s.id==='lambda') return `Traffic is classified as ${r.trafficClass}; request-driven compute fits this workload.`;
  if(s.id==='fargate') return `Traffic is classified as large; sustained workloads favor managed containers.`;
  if(s.id==='dynamodb') return 'The selected database requirement is NoSQL.';
  if(s.id==='rds') return 'The selected database requirement is relational / SQL.';
  if(s.id==='cognito') return 'User authentication was enabled.';
  if(s.id==='cloudfront') return 'Traffic or availability requirements justify edge delivery.';
  if(s.id==='route53') return 'High availability was requested, so DNS and health-aware routing are included.';
  if(s.id==='bedrock') return 'AI is used after deterministic selection to explain the architecture.';
  if(s.id==='alb') return 'Container traffic needs a managed application load balancer.';
  return `Required foundation service for the selected architecture and ${q.applicationType||'workload'} context.`;
}

function serviceConnections(service,r){
  const sv=r.services||[], byId=id=>sv.find(x=>x.id===id);
  const map={
    s3:['Amazon API Gateway (visualized foundation path)'],
    'api-gateway':['AWS Lambda / AWS Fargate (compute path)','Amazon Cognito (when authentication is enabled)','Amazon CloudWatch (observability)'],
    cloudwatch:['API / compute / database logs and metrics (conceptual)'],
    lambda:['Amazon API Gateway','Selected database, if any','Amazon Bedrock for explanation workflow'],
    fargate:['Application Load Balancer','Selected application database, if any'],
    alb:['AWS Fargate'],
    rds:['Application compute (AWS Lambda or AWS Fargate)'],
    dynamodb:['Application compute (AWS Lambda or AWS Fargate)'],
    cognito:['Amazon API Gateway authorization boundary'],
    cloudfront:['Static/content delivery and application entry path'],
    route53:['DNS entry and availability routing'],
    bedrock:['AWS Lambda recommendation explanation workflow']
  };
  return (map[service.id]||[]).filter(x=>{
    if(x.includes('Fargate')&&!byId('fargate')) return false;
    if(x.includes('Lambda')&&!byId('lambda')) return false;
    if(x.includes('Cognito')&&!byId('cognito')) return false;
    if(x.includes('Bedrock')&&!byId('bedrock')) return false;
    if(x.includes('Load Balancer')&&!byId('alb')) return false;
    if(x.includes('database')&&!byId('rds')&&!byId('dynamodb')) return false;
    return true;
  });
}
function configurationNotes(s,r){
  const q=r.requirements||{};
  const common='Set least-privilege IAM, encryption, logging/retention, quotas and alarms before production.';
  const notes={
    s3:'Choose bucket access policy, encryption, lifecycle rules, versioning, and public-access blocking. '+common,
    'api-gateway':'Confirm route methods, Cognito authorizer, throttling, CORS allow-list, and request validation. '+common,
    cloudwatch:'Define log retention, actionable alarms, dashboards, and metric filters.',
    lambda:'Tune memory/timeout, concurrency, retries, environment variables, and IAM permissions. '+common,
    fargate:'Size task CPU/memory, desired count, health checks, autoscaling, and private networking. '+common,
    alb:'Configure listeners, target group health checks, TLS certificate, and security groups.',
    rds:`Choose engine/version, instance/storage sizing, backups, encryption, and ${q.availability==='high'?'Multi-AZ':'availability'} strategy. ${common}`,
    dynamodb:'Choose on-demand/provisioned capacity, partition-key access patterns, backups, encryption, and TTL where relevant. '+common,
    cognito:'Review password policy, verification, app-client settings, token expiry, and MFA requirements.',
    cloudfront:'Configure origins, cache behaviors, TLS, access restrictions, and invalidation strategy.',
    route53:'Configure hosted zone, records, health checks, and failover policy where needed.',
    bedrock:'Verify model access in the selected region, IAM invoke permission, quotas, and fallback behavior.'
  };
  return notes[s.id]||common;
}
function graphNodes(r){
  const sv=r.services||[];
  const rank={Storage:0,Security:1,API:2,Compute:3,Database:4,Delivery:5,Networking:6,Observability:7,AI:8};
  const nodes=sv.map((s,i)=>({s,i,rank:rank[s.category]??4}));
  nodes.sort((a,b)=>a.rank-b.rank);
  const yByCat={Storage:90,Security:145,API:200,Compute:255,Database:310,Delivery:145,Networking:200,Observability:365,AI:365};
  const xByRank={0:95,1:95,2:245,3:395,4:555,5:710,6:710,7:555,8:710};
  return nodes.map((n,i)=>({...n,x:xByRank[n.rank]??(160+(i%4)*150),y:yByCat[n.s.category]??100+(i%4)*70}));
}
function graphLinks(nodes){
  const byCat=c=>nodes.filter(n=>n.s.category===c);
  const links=[];
  const add=(a,b)=>{if(a&&b) links.push([a,b]);};
  const storage=byCat('Storage')[0], api=byCat('API')[0], sec=byCat('Security')[0], compute=byCat('Compute')[0], db=byCat('Database')[0], delivery=byCat('Delivery')[0], net=byCat('Networking')[0], obs=byCat('Observability')[0], ai=byCat('AI')[0];
  add(storage,api); add(sec,api); add(delivery,storage); add(net,delivery||api); add(api,compute); add(compute,db); add(compute,ai); add(api,obs); add(compute,obs); add(db,obs); add(delivery,api);
  return links;
}
function renderGraph(r){
  const nodes=graphNodes(r), links=graphLinks(nodes), w=820,h=450;
  const nodeSvg=nodes.map(n=>`<g class="graph-node" data-index="${n.i}" transform="translate(${n.x},${n.y})"><circle r="31" class="node-halo"/><circle r="25" class="node-circle"/><text class="node-icon" text-anchor="middle" y="5">${escapeHtml(serviceIcon(n.s))}</text><text class="node-label" text-anchor="middle" y="50">${escapeHtml(shortName(n.s.name))}</text></g>`).join('');
  const linkSvg=links.map(([a,b])=>`<line class="graph-link" data-from="${a.i}" data-to="${b.i}" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"/><circle class="flow-dot" r="3"><animate attributeName="cx" values="${a.x};${b.x}" dur="2.1s" repeatCount="indefinite"/><animate attributeName="cy" values="${a.y};${b.y}" dur="2.1s" repeatCount="indefinite"/></circle>`).join('');
  $('architectureGraph').innerHTML=`<div class="graph-stage"><svg id="architectureSvg" viewBox="0 0 ${w} ${h}" role="img" aria-label="Generated architecture graph"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z"/></marker><filter id="glow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g id="graphWorld">${linkSvg}${nodeSvg}</g></svg></div>`;
  document.querySelectorAll('.graph-node').forEach(g=>g.addEventListener('click',()=>inspectService(r.services[Number(g.dataset.index)])));
  graphState={scale:1,x:0,y:0,dragging:false,px:0,py:0,lastX:0,lastY:0};
  bindGraphControls();
}
function shortName(name){return name.replace(/^Amazon /,'').replace(/^AWS /,'').replace('Application ','').slice(0,20);}
function bindGraphControls(){
  const viewport=$('architectureGraph'), world=$('graphWorld');
  let nodeDrag=null;
  const svg=$('architectureSvg');
  const toSvgPoint=e=>{const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;return pt.matrixTransform(world.getScreenCTM().inverse());};
  document.querySelectorAll('.graph-node').forEach(g=>{
    g.style.cursor='grab';
    g.addEventListener('pointerdown',e=>{
      e.stopPropagation(); e.preventDefault();
      const point=toSvgPoint(e), match=g.getAttribute('transform').match(/translate\(([-\d.]+),\s*([-\d.]+)\)/);
      nodeDrag={g,index:Number(g.dataset.index),startX:point.x,startY:point.y,x:Number(match?.[1]||0),y:Number(match?.[2]||0),moved:false};
      g.setPointerCapture?.(e.pointerId); g.style.cursor='grabbing';
    });
    g.addEventListener('pointermove',e=>{
      if(!nodeDrag||nodeDrag.g!==g)return;
      const point=toSvgPoint(e), dx=point.x-nodeDrag.startX,dy=point.y-nodeDrag.startY;
      if(Math.abs(dx)+Math.abs(dy)>2)nodeDrag.moved=true;
      g.setAttribute('transform',`translate(${nodeDrag.x+dx},${nodeDrag.y+dy})`);
      updateGraphLinks();
    });
    const finish=()=>{if(nodeDrag?.g===g){g.style.cursor='grab';nodeDrag=null;}};
    g.addEventListener('pointerup',finish);g.addEventListener('pointercancel',finish);
    g.addEventListener('click',()=>inspectService(currentRecommendation.services[Number(g.dataset.index)]));
  });
  viewport.onwheel=e=>{e.preventDefault(); graphState.scale=Math.min(2.2,Math.max(.55,graphState.scale+(e.deltaY<0?.1:-.1))); applyGraphTransform(world);};
  viewport.onpointerdown=e=>{if(e.target.closest('.graph-node'))return;graphState.dragging=true;graphState.px=e.clientX;graphState.py=e.clientY;viewport.setPointerCapture(e.pointerId);};
  viewport.onpointermove=e=>{if(!graphState.dragging)return;graphState.x+=e.clientX-graphState.px;graphState.y+=e.clientY-graphState.py;graphState.px=e.clientX;graphState.py=e.clientY;applyGraphTransform(world);};
  viewport.onpointerup=()=>graphState.dragging=false; viewport.onpointercancel=()=>graphState.dragging=false;
  $('fitGraph').onclick=()=>{graphState={...graphState,scale:1,x:0,y:0};applyGraphTransform(world);};
  $('exportSvg').onclick=()=>exportArchitecture('svg');
  $('exportPng').onclick=()=>exportArchitecture('png');
  $('exportJson').onclick=()=>exportArchitecture('json');
}
function updateGraphLinks(){
  const positions={};
  document.querySelectorAll('.graph-node').forEach(g=>{const m=g.getAttribute('transform').match(/translate\(([-\d.]+),\s*([-\d.]+)\)/);positions[g.dataset.index]=[Number(m?.[1]||0),Number(m?.[2]||0)];});
  document.querySelectorAll('.graph-link').forEach(line=>{const a=positions[line.dataset.from],b=positions[line.dataset.to];if(a&&b){line.setAttribute('x1',a[0]);line.setAttribute('y1',a[1]);line.setAttribute('x2',b[0]);line.setAttribute('y2',b[1]);}});
}
function applyGraphTransform(world){world.style.transform=`translate(${graphState.x}px,${graphState.y}px) scale(${graphState.scale})`;world.style.transformOrigin='410px 225px';}
function exportArchitecture(type){
  if(type==='json'){
    if(!currentRecommendation)return;
    const payload={exportedAt:new Date().toISOString(),recommendation:currentRecommendation,graph:{nodes:[...document.querySelectorAll('.graph-node')].map(g=>{const m=g.getAttribute('transform').match(/translate\(([-\d.]+),\s*([-\d.]+)\)/);return {serviceIndex:Number(g.dataset.index),x:Number(m?.[1]||0),y:Number(m?.[2]||0)};}),scale:graphState.scale,pan:{x:graphState.x,y:graphState.y}}};
    downloadBlob(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),`cloudarchitect-${Date.now()}.json`);return;
  }
  const svg=$('architectureSvg'); if(!svg)return;
  const copy=svg.cloneNode(true); copy.setAttribute('xmlns','http://www.w3.org/2000/svg'); copy.setAttribute('width','1640');copy.setAttribute('height','900');
  const blob=new Blob([new XMLSerializer().serializeToString(copy)],{type:'image/svg+xml'});
  if(type==='svg'){downloadBlob(blob,`cloudarchitect-${Date.now()}.svg`);return;}
  const url=URL.createObjectURL(blob), img=new Image();
  img.onload=()=>{const c=document.createElement('canvas');c.width=1640;c.height=900;const ctx=c.getContext('2d');ctx.fillStyle='#050B17';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0);URL.revokeObjectURL(url);c.toBlob(b=>downloadBlob(b,`cloudarchitect-${Date.now()}.png`),'image/png');}; img.src=url;
}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}

function renderDecisionTree(r){
  const q=r.requirements||{}, checks=[
    ['Workload','Traffic classification',`${Number(q.expectedUsers||0).toLocaleString()} users → ${r.trafficClass}`],
    ['Compute',r.trafficClass==='large'?'Fargate + ALB':'Lambda',r.trafficClass==='large'?'Large sustained workload':'Small/medium request-driven workload'],
    ['Data',q.database==='relational'?'RDS / Aurora':q.database==='nosql'?'DynamoDB':'No database',`Database preference: ${q.database}`],
    ['Resilience',q.availability==='high'?'CloudFront + Route 53':'Standard delivery',`Availability: ${q.availability}`],
    ['Identity',q.authentication?'Cognito':'No Cognito',q.authentication?'Authentication enabled':'Authentication not requested'],
    ['Explanation','Bedrock', 'AI explains the deterministic result after selection']
  ];
  $('decisionTree').innerHTML=checks.map((c,i)=>`<div class="decision-row"><span class="decision-index">${String(i+1).padStart(2,'0')}</span><div><b>${escapeHtml(c[0])}</b><strong>${escapeHtml(c[1])}</strong><small>${escapeHtml(c[2])}</small></div></div>`).join('');
}
function renderHealth(r){
  const q=r.requirements||{}, sv=r.services||[], has=x=>sv.some(s=>s.id===x);
  const checks=[
    [has('cloudwatch'),'Observability','CloudWatch is included for logs, metrics and operational visibility.'],
    [q.authentication?has('cognito'):true,'Identity boundary',q.authentication?'Cognito is included because authentication was requested.':'No authentication service was requested.'],
    [q.availability==='high'?(has('cloudfront')&&has('route53')):true,'Availability',q.availability==='high'?'Edge delivery and DNS routing are included for the high-availability requirement.':'Standard availability was requested.'],
    [q.budget==='low' && r.trafficClass==='large' ? false:true,'Budget tension',q.budget==='low'&&r.trafficClass==='large'?'Low budget + large workload needs explicit cost validation.':'No rule-triggered budget tension detected.'],
    [true,'Deployment scope','This is a recommendation only; recommended workload resources are not automatically deployed.']
  ];
  $('healthChecklist').innerHTML=checks.map(c=>`<div class="health-row"><span class="${c[0]?'ok':'warn'}">${c[0]?'✓':'!'}</span><div><strong>${escapeHtml(c[1])}</strong><p>${escapeHtml(c[2])}</p></div></div>`).join('');
}

function renderCostEstimate(r){
  const q=r.requirements||{}, sv=r.services||[];
  const drivers=[
    ['Compute',r.trafficClass==='large'?'Higher sensitivity: Fargate tasks + load balancer':'Usage-driven: Lambda requests and duration'],
    ['Database',q.database==='none'?'No managed application database selected':q.database==='relational'?'RDS/Aurora instance, storage, backups and Multi-AZ if configured':'DynamoDB request volume, data storage and capacity mode'],
    ['Delivery & availability',q.availability==='high'?'CloudFront and Route 53 add usage/configuration cost':'Standard delivery profile'],
    ['AI explanation','Bedrock model input/output tokens per generated explanation'],
    ['Observability','CloudWatch log ingestion, retention, metrics and alarms']
  ];
  $('costEstimateBadge').textContent=`${r.costCategory} · relative`;
  $('costEstimatePanel').innerHTML=`<div class="cost-score"><span>Rule-based category</span><strong>${escapeHtml(r.costCategory)}</strong><small>Based on the backend's existing qualitative score; not a monthly USD estimate.</small></div><div class="cost-drivers">${drivers.map(([a,b])=>`<div><strong>${escapeHtml(a)}</strong><p>${escapeHtml(b)}</p></div>`).join('')}</div><p class="hint">For a monetary estimate, enter region, usage/request volume, data transfer, storage, runtime sizing and database configuration in the AWS Pricing Calculator. No pricing API or live AWS bill data is queried.</p>`;
}
$('loadCompareBtn').addEventListener('click',async()=>{
  const btn=$('loadCompareBtn');btn.disabled=true;
  try{
    const data=await api('/recommendations?limit=50');
    comparisonItems=(data.items||[]).filter(x=>x.recommendationId!==currentRecommendation?.recommendationId);
    $('compareSelect').innerHTML='<option value="">Select a saved architecture…</option>'+comparisonItems.map((x,i)=>`<option value="${i}">${escapeHtml(x.requirements?.applicationType||'Application')} · ${escapeHtml(x.costCategory||'')} · ${escapeHtml(new Date(x.createdAt||x.generatedAt||Date.now()).toLocaleString())}</option>`).join('');
    if(!comparisonItems.length)$('comparisonPanel').innerHTML='<p class="hint">No other saved designs found. Generate and save another recommendation first.</p>';
    else toast(`Loaded ${comparisonItems.length} saved design(s)`);
  }catch(err){toast(err.message)}finally{btn.disabled=false;}
});
$('compareSelect').addEventListener('change',()=>{
  const other=comparisonItems[Number($('compareSelect').value)];
  if(!other||!currentRecommendation){$('comparisonPanel').innerHTML='<p class="hint">Choose a saved design to compare.</p>';return;}
  const a=currentRecommendation,b=other, names=r=>(r.services||[]).map(s=>s.name), A=names(a),B=names(b);
  const rows=[
    ['Traffic class',a.trafficClass,b.trafficClass],
    ['Relative cost category',a.costCategory,b.costCategory],
    ['Database',a.requirements?.database||'—',b.requirements?.database||'—'],
    ['Availability',a.requirements?.availability||'—',b.requirements?.availability||'—'],
    ['Expected users',Number(a.requirements?.expectedUsers||0).toLocaleString(),Number(b.requirements?.expectedUsers||0).toLocaleString()],
    ['Services',`${A.length} selected`,`${B.length} selected`],
    ['Only in current',A.filter(n=>!B.includes(n)).join(', ')||'None', ''],
    ['Only in saved', '',B.filter(n=>!A.includes(n)).join(', ')||'None']
  ];
  $('comparisonPanel').innerHTML=`<div class="compare-columns"><span>Current design</span><span>Saved design</span></div><div class="compare-table">${rows.map(([label,left,right])=>`<div class="compare-row"><b>${escapeHtml(label)}</b><span>${escapeHtml(left)}</span><span>${escapeHtml(right)}</span></div>`).join('')}</div><p class="hint">Comparison uses stored recommendation data. It does not deploy either architecture or calculate live prices.</p>`;
});

$('saveBtn').addEventListener('click',async()=>{if(!currentRecommendation)return; try{await api('/recommendations',{method:'POST',body:JSON.stringify(currentRecommendation)});toast('Recommendation saved');}catch(err){toast(err.message)}});
$('historyBtn').addEventListener('click',async()=>{try{const data=await api('/recommendations?limit=30'); $('historyList').innerHTML=data.items.length?data.items.map(x=>`<article class="history-item"><strong>${escapeHtml(x.requirements?.applicationType||'Application')} · ${escapeHtml(x.costCategory||'')} cost</strong><div class="history-meta">${new Date(x.createdAt||x.generatedAt).toLocaleString()} · ${escapeHtml((x.services||[]).map(s=>s.name).join(' · '))}</div></article>`).join(''):'<p class="hint">No saved recommendations yet.</p>'; $('historyDialog').showModal();}catch(err){toast(err.message)}});
$('closeHistory').addEventListener('click',()=>$('historyDialog').close());

const hero=$('hero3d');
if(hero && !matchMedia('(prefers-reduced-motion: reduce)').matches){
  hero.addEventListener('pointermove',e=>{const r=hero.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;hero.style.setProperty('--mx',`${x*16}px`);hero.style.setProperty('--my',`${y*12}px`);});
  hero.addEventListener('pointerleave',()=>{hero.style.setProperty('--mx','0px');hero.style.setProperty('--my','0px');});
}

// Hero actions are navigation-only; they do not bypass authentication or alter backend behavior.
const startDesignBtn = $('startDesignBtn');
if (startDesignBtn) startDesignBtn.addEventListener('click', () => {
  const target = $('appSection').classList.contains('hidden') ? $('authSection') : $('requirementsForm');
  target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
});
const exploreGraphBtn = $('exploreGraphBtn');
if (exploreGraphBtn) exploreGraphBtn.addEventListener('click', () => {
  const target = $('resultSection').classList.contains('hidden') ? $('requirementsForm') : $('architectureGraph');
  target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
});

initPool();
if(!configured()) showMessage('This package is ready to deploy. Run scripts/deploy.sh or scripts/deploy.ps1 to inject the AWS configuration.',false);
else { const user=sessionUser(); if(user) user.getSession((err,session)=>{if(!err&&session.isValid()){const email=session.getIdToken().payload.email||user.getUsername();showApp(email);}}); }
